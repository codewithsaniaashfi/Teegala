package com.tnsif.First;

public class Day {

	public static void main(String[] args) {
	
			 System.out.println("Hell0");
		 

	}

}
