package com.tns.azlansami;

public interface Phone {
	void call();
	void sms();
	void app();
}

