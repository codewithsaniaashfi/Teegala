package com.tns.azlansami;

class SamsungPhone implements Phone {
	public void call(){
		System.out.println("Samsung calls available");
	}
	public void sms(){
		System.out.println("Samsung sms un-available");
	}
	public void sms(){
		System.out.println("Samsung phone un-available");
	}
}

