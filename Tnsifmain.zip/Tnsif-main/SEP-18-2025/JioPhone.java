package com.tns.azlansami;

class JioPhone implements Phone {
	public void call(){
		System.out.println("Jio calls un-available");
	}
	public void sms(){
		System.out.println("Jio sms available");
	}
}

