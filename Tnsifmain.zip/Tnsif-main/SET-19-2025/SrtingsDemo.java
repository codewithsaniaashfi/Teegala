package com.tns.azlansami;

public class SrtingsDemo {

	public static void main(String[] args) {
		//string
		String str = "Strings";
		System.out.println(str+ " azlansami");
		
		//string buffer
		StringBuffer azz = new StringBuffer("String");
		azz.append(" Buffer");
		System.out.println(azz);
		
		//string builder
		StringBuilder azzu = new StringBuilder("String");
		azzu.append(" Builder");
		System.out.println(azzu);
	}

}

