package com.tns.azlansami;

public class Int2Int implements Interface2 {
	public void int1() {
			System.out.println("Call Method from Interface 1");
		}
	public void int2() {
		System.out.println("Call Method from Interface 2");
	}
}

