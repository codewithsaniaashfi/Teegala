package com.tns.azlansami;

public interface Interface2 extends Interface1{
	void int2();
}

