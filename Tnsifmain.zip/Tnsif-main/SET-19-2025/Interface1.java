package com.tns.azlansami;

public interface Interface1  {
	void int1();
}

