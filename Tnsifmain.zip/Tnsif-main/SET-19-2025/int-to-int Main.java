package com.tns.azlansami;

public class Int2IntMain {

	public static void main(String[] args) {
		Int2Int obj = new Int2Int();
		obj.int1();
		obj.int2();

	}

}

