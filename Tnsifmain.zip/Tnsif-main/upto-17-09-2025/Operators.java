package com.operator;

public class Operators {
	public static void main(String[] args) {
	int a =14;
	int b = ++a;
	 System.out.println(a+""+b);
	}
}

